import './components/home/home'
// 记载框架默认的组件
import './components/timer/myTimer'
