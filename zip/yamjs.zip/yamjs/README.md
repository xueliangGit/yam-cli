# Yam-cli 

YamJS 一个webComponent的渲染函数组件;兼容非webComponent渲染,是一个针对html的开发的一个组件基类，让你开发一个组件，可以运行在原生HTML/vue/react等环境。

## 使用

```bash 
  # 安装依赖
  npm i 
  # 开始开发
  yarn dev
  # 打包程序
  yarn build
  # 分析
  yarn analyz
```
## yamjs版本升级 `npm i yamjs@latest -S`
 